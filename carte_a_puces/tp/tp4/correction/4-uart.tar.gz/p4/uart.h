#ifndef SERIAL_H
#define SERIAL_H

#include <stdio.h>
#include <stdint.h>

void UART__init(uint32_t);
#endif
