#ifndef MAKE_CREDENTIAL_H
#define MAKE_CREDENTIAL_H
#include <stdint.h>

#include "error.h"

status_t MakeCredential(uint8_t *);


#endif
