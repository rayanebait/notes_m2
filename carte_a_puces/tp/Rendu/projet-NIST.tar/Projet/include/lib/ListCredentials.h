#ifndef LIST_CREDENTIAL_H
#define LIST_CREDENTIAL_H

#include "error.h"

status_t ListCredential(void);

#endif