#ifndef RESET_H
#define RESET_H

#include "error.h"

status_t Reset(void);

#endif