#ifndef GET_APPROVAL_H
#define GET_APPROVAL_H

#include "error.h"

void 
set_from_make_credential();

void 
unset_from_make_credential();

status_t get_approval(void);

#endif